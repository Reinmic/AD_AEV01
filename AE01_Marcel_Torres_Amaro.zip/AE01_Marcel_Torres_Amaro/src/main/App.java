package main;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Esta clase representa una aplicación de gestión de archivos que permite al
 * usuario seleccionar un directorio, cargar la lista de archivos, buscar
 * archivos y fusionar múltiples archivos de texto en uno.
 */

public class App extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtSearch;
	private JTextField txtNewFile;
	private JTextField txtDirectory;
	private String currentDirectory = "";
	private JList<String> fileList;
	private boolean ascending = true;
	private String sortingCriteria = "Name";
	private static final String FILE_EXTENSION = ".txt";

	/**
	 * Constructor de la aplicación que inicializa la interfaz de usuario y
	 * configura los manejadores de eventos.
	 */

	public App() {

		setTitle("File Management");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 888, 478);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 120, 803, 186);
		contentPane.add(scrollPane);
		fileList = new JList<>();
		scrollPane.setViewportView(fileList);

		JLabel lblDirectory = new JLabel("Current Directory:");
		lblDirectory.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDirectory.setBounds(36, 20, 135, 26);
		contentPane.add(lblDirectory);

		txtDirectory = new JTextField();
		txtDirectory.setEditable(false);
		txtDirectory.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtDirectory.setColumns(10);
		txtDirectory.setBounds(171, 20, 400, 26);
		contentPane.add(txtDirectory);

		JButton btnSelectDirectory = new JButton("Select Directory...");
		btnSelectDirectory.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSelectDirectory.setBounds(588, 20, 251, 26);
		contentPane.add(btnSelectDirectory);

		btnSelectDirectory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectDirectory();
				txtDirectory.setText(currentDirectory);
			}
		});

		JLabel lblSortBy = new JLabel("Sort By:");
		lblSortBy.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSortBy.setBounds(36, 70, 60, 26);
		contentPane.add(lblSortBy);

		JComboBox<String> cmbSortBy = new JComboBox<>();
		cmbSortBy.setFont(new Font("Tahoma", Font.PLAIN, 12));
		cmbSortBy.setModel(new DefaultComboBoxModel<>(new String[] { "Name", "Size", "Last Modified" }));
		cmbSortBy.setBounds(100, 70, 120, 26);
		contentPane.add(cmbSortBy);

		cmbSortBy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sortingCriteria = (String) cmbSortBy.getSelectedItem();
				loadFileList();
			}
		});

		JRadioButton rdbtnAscending = new JRadioButton("Ascending");
		rdbtnAscending.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnAscending.setBounds(240, 70, 100, 26);
		contentPane.add(rdbtnAscending);
		rdbtnAscending.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ascending = true;
				loadFileList();
			}
		});

		JRadioButton rdbtnDescending = new JRadioButton("Descending");
		rdbtnDescending.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnDescending.setBounds(340, 70, 100, 26);
		contentPane.add(rdbtnDescending);
		rdbtnDescending.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ascending = false;
				loadFileList();
			}
		});

		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(rdbtnAscending);
		buttonGroup.add(rdbtnDescending);

		JButton btnLoad = new JButton("Load");
		btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnLoad.setBounds(460, 70, 100, 26);
		contentPane.add(btnLoad);

		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadFileList();
			}
		});

		txtSearch = new JTextField();
		txtSearch.setBounds(36, 320, 537, 26);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);

		JButton btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSearch.setBounds(588, 320, 100, 26);
		contentPane.add(btnSearch);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchFiles();
			}
		});

		JLabel lblNewFileName = new JLabel("New File Name:");
		lblNewFileName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewFileName.setBounds(36, 370, 135, 26);
		contentPane.add(lblNewFileName);

		txtNewFile = new JTextField();
		txtNewFile.setColumns(10);
		txtNewFile.setBounds(171, 370, 400, 26);
		contentPane.add(txtNewFile);

		JButton btnMergeFiles = new JButton("Merge Files");
		btnMergeFiles.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnMergeFiles.setBounds(588, 370, 100, 26);
		contentPane.add(btnMergeFiles);
		btnMergeFiles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mergeFiles();
			}
		});

		btnMergeFiles.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnMergeFiles.setBounds(711, 398, 128, 26);
		contentPane.add(btnMergeFiles);

		txtDirectory = new JTextField();
		txtDirectory.setEditable(false);
		txtDirectory.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtDirectory.setColumns(10);
		txtDirectory.setBounds(36, 20, 537, 26);
		contentPane.add(txtDirectory);

		JButton btnSelectDirectory1 = new JButton("Select Directory...");
		btnSelectDirectory1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSelectDirectory1.setBounds(588, 20, 251, 26);
		contentPane.add(btnSelectDirectory1);

		btnSelectDirectory1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectDirectory();
				txtDirectory.setText(currentDirectory);
			}
		});
	}

	/**
	 * Permite al usuario seleccionar un directorio mediante un cuadro de diálogo.
	 */

	private void selectDirectory() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int returnValue = fileChooser.showOpenDialog(null);
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedDirectory = fileChooser.getSelectedFile();
			currentDirectory = selectedDirectory.getAbsolutePath();
			loadFileList();
		}
	}

	/**
	 * Carga y muestra la lista de archivos en el directorio actual.
	 */

	public void loadFileList() {
		DefaultListModel<String> listModel = new DefaultListModel<>();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss");
		File folder = new File(currentDirectory);

		File[] fileList = folder
				.listFiles(file -> file.isFile() && file.getName().toLowerCase().endsWith(FILE_EXTENSION));

		Arrays.sort(fileList, (file1, file2) -> {
			int comparator = 0;
			switch (sortingCriteria) {
			case "Name":
				comparator = file1.getName().compareTo(file2.getName());
				break;
			case "Size":
				comparator = Long.compare(file1.length(), file2.length());
				break;
			case "Last Modified":
				comparator = Long.compare(file1.lastModified(), file2.lastModified());
				break;
			}
			return ascending ? comparator : -comparator;
		});

		for (File file : fileList) {
			String name = file.getName();
			long size = file.length();
			String lastModified = dateFormat.format(file.lastModified());
			String extension = name.substring(name.lastIndexOf(".") + 1);

			String info = String.format("%s | Last Modified: %s | Size: %d bytes | Extension: %s", name, lastModified,
					size, extension);

			listModel.addElement(info);
		}

		this.fileList.setModel(listModel);
		this.fileList.repaint();
	}

    /**
     * Realiza una búsqueda de archivos en función de un término de búsqueda.
     */
	
	public void searchFiles() {
		DefaultListModel<String> resultModel = new DefaultListModel<>();
		File folder = new File(currentDirectory);
		File[] fileList = folder
				.listFiles(file -> file.isFile() && file.getName().toLowerCase().endsWith(FILE_EXTENSION));

		String searchWord = txtSearch.getText().toLowerCase();

		for (File file : fileList) {
			int matchCount = countMatches(searchWord, file);

			if (matchCount > 0) {
				String fileInfo = file.getName() + " --> Matches with '" + searchWord + "': " + matchCount;
				resultModel.addElement(fileInfo);
			}
		}

		this.fileList.setModel(resultModel);
		this.fileList.repaint();
	}

	   /**
     * Cuenta las ocurrencias de un término de búsqueda en un archivo.
     */
	
	public int countMatches(String searchWord, File file) {
		int count = 0;

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			Pattern pattern = Pattern.compile("\\b" + Pattern.quote(searchWord) + "\\b", Pattern.CASE_INSENSITIVE);

			while ((line = reader.readLine()) != null) {
				Matcher matcher = pattern.matcher(line);
				while (matcher.find()) {
					count++;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return count;
	}

    /**
     * Fusiona los archivos seleccionados en uno nuevo.
     */
	
	public void mergeFiles() {
		String newFileName = txtNewFile.getText();
		ArrayList<String> selectedFiles = new ArrayList<>();
		Object[] selectedValues = fileList.getSelectedValuesList().toArray();

		for (Object selectedValue : selectedValues) {
			String element = (String) selectedValue;
			String fileName = getFileNameFromInfo(element);
			selectedFiles.add(fileName);
		}

		if (selectedFiles.size() > 1) {
			if (mergeSelectedFiles(selectedFiles, newFileName)) {
				JOptionPane.showMessageDialog(null, "Merge completed successfully", "Operation Completed",
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "The specified file already exists", "Merge Failed",
						JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			JOptionPane.showMessageDialog(null, "Select more than one file to merge.", "Error",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private boolean mergeSelectedFiles(ArrayList<String> selectedFiles, String newFileName) {
		boolean success = false;
		File newFile = new File(currentDirectory + File.separator + newFileName + FILE_EXTENSION);

		if (!newFile.exists()) {
			try {
				FileWriter fileWriter = new FileWriter(newFile);
				BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

				for (String selectedFile : selectedFiles) {
					File currentFile = new File(currentDirectory + File.separator + selectedFile + FILE_EXTENSION);

					if (currentFile.exists() && currentFile.isFile()) {
						try (FileReader fileReader = new FileReader(currentFile);
								BufferedReader bufferedReader = new BufferedReader(fileReader)) {
							String line;
							while ((line = bufferedReader.readLine()) != null) {
								bufferedWriter.write(line);
								bufferedWriter.newLine();
							}
							bufferedReader.close();
							fileReader.close();
						}
					}
				}

				bufferedWriter.close();
				fileWriter.close();
				success = true;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return success;
	}

    /**
     * Obtiene el nombre de archivo a partir de la información de la lista.
     */
	
	private String getFileNameFromInfo(String fileInfo) {
		int index = fileInfo.indexOf(FILE_EXTENSION);
		if (index != -1) {
			return fileInfo.substring(0, index);
		}
		return fileInfo;
	}


    /**
     * Método principal que crea una instancia de la aplicación y la hace visible.
     */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				App frame = new App();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}
}